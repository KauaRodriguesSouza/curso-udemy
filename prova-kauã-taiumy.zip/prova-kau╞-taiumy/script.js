document.getElementById("q1").style.backgroundColor = 'blue '
document.getElementById("q1").style.textAlign = 'center'

// lição 2

var l1 = document.getElementById("n1")
var l2 = document.getElementById("n2")

function  clicar(){

    var l1 = document.getElementById("n1")
    var texto = l1.value
    console.log(texto);

}

// liçao 3

function  clica(){

    var result = document.getElementById("para")

    var l4 = document.getElementById("k1")

    var texto = l4.value
    
    if (texto <= 100){
         result.innerHTML = "você esta em uma velocidade permitida"
    }
    else{
       result.innerHTML = "você esta em uma velocidade muito alta você foi multado"
    }

}

// lição 4

document.getElementsByTagName("h2")[1].style.backgroundColor = "yellow"

// lição 5

function somar(){

    var p1 = document.getElementById("a1")
    var p2 = document.getElementById("a2")
    var result1 = document.getElementById("prag")

    var valor1 = p1.value
    var valor2 = p2.value

    var clc = Number(valor1) + Number(valor2) 

    result1.innerHTML = `a soma dos valores é igual a : ${clc}`

}

    // lição 6 

    var ctx = []
     var j2 = document.getElementById("en1")
    var result1 = document.getElementById("paragr")

function clicar2(){

    
    var j1 = document.getElementById("te1")
    
    var cx1 = j1

    ctx.push(cx1.value)

    result1.innerHTML = ctx

}

// lição 7

for ( var y = 3 ; y <= 6 ; y++){

    document.querySelectorAll('p')[y].style.backgroundColor = "blue" 

}

// lição 8

function segurou(){

    var segu = document.getElementsByTagName("div")[0]

    segu.style.backgroundColor = "yellow"
    segu.style.color = "black"
    segu.innerHTML = "segurou"

}

//  lição 9

function soltou(){

    var segu = document.getElementsByTagName("div")[0]

    segu.style.backgroundColor = "blue"
    segu.innerHTML = "soltou"

}

// lição 10

function clicar3(){

    var p = document.getElementById("pr1")

    var t1 = document.getElementById("text1")
    var d1 = t1.value

    if (d1 >= 9){
        p.innerHTML = `sua nota é ${d1} está execelente`
    }
    else if (d1 >= 7){
        p.innerHTML = `sua nota é ${d1} está boa`
    }
    else if (d1 >= 5){
        p.innerHTML = `sua nota é ${d1} está razoavel precisa melhorar`
    }
    else if (d1 >= 3){
        p.innerHTML = `sua nota é ${d1} está ruim estude mais`
    }
    else if (d1 < 3){
        p.innerHTML = `sua nota é ${d1} está pessima precisara de recuperação `
    }
    

}